package com.example.processmanager;

import android.util.Log;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;


public class RootUtil {
    public static final String LOG_TAG = "ROOT";

    public static boolean isDeviceRooted(){
        // Note that this will ask per for supersu permission if a su manager is installed
        try {
            java.lang.Process process = Runtime.getRuntime().exec("su");

            DataOutputStream writeTo = new DataOutputStream(process.getOutputStream());
            BufferedReader readFrom = new BufferedReader(new InputStreamReader(process.getInputStream()));

            writeTo.writeBytes("id\n");
            writeTo.flush();

            String out = readFrom.readLine();

            if(out == null){
                Log.d(LOG_TAG, "isDeviceRooted: no output from su");
                return false;
            }
            else if(out.contains("uid=0")){
                Log.d(LOG_TAG, "isDeviceRooted: device rooted");
                writeTo.writeBytes("exit\n");
                writeTo.flush();
                return true;
            }
            else {
                Log.d(LOG_TAG, "isDeviceRooted: non su user");
                writeTo.writeBytes("exit\n");
                writeTo.flush();
                return false;
            }
        }
        catch (IOException e){
            Log.d(LOG_TAG, "isDeviceRooted: not rooted with: " + e.getMessage());
            return  false;
        }
    }

    public static java.lang.Process getSuProcess() throws IOException{
        return Runtime.getRuntime().exec("su");
    }
}
