package com.example.processmanager.recyclerviewclasses;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.processmanager.ProcessManager;
import com.example.processmanager.ProcessManager.Process;
import com.example.processmanager.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ProcessListAdaptor extends RecyclerView.Adapter<ProcessListAdaptor.ProcessViewHolder> {
    private ArrayList<Process> processList;
    private KillCallback killCallback;

    private int sortingByName = 0;
    private int sortingByPid = 0;
    private String filterBy = "";

    class ProcessViewHolder extends RecyclerView.ViewHolder{
        private Process process;
        private final TextView processName;
        private final TextView processPid;
        private final Button killButton;

        public ProcessViewHolder(View view){
            super(view);

            processName = view.findViewById(R.id.process_name);
            processPid = view.findViewById(R.id.process_pid);
            killButton = view.findViewById(R.id.kill_button);

            killButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ProcessManager.killProcess(ProcessViewHolder.this.process);
                    ProcessListAdaptor.this.killCallback.onKill();
                }
            });
        }

        public void bindProcess(Process process){
            this.process = process;
            this.processName.setText(process.getName());
            this.processPid.setText(String.valueOf(process.getPid()));
        }
    }

    public interface KillCallback{
        public void onKill();
    }

    public ProcessListAdaptor(ArrayList<Process> processList, KillCallback callback){
        this.processList = processList;
        this.killCallback = callback;
    }

    public void refreshList(ArrayList<Process> processList){
        this.processList = processList;
        this.sort();
        this.filter();
        this.notifyDataSetChanged();
    }

    private void sort() {
        if(sortingByPid != 0){
            Collections.sort(this.processList, new Comparator<Process>() {
                @Override
                public int compare(Process process1, Process process2) {
                    if(process1.getPid() == process2.getPid())
                        return 0;

                    if(sortingByPid == 1)
                        return process1.getPid() > process2.getPid() ? 1 : -1;
                    else
                        return process1.getPid() > process2.getPid() ? -1 : 1;
                }
            });
        }
        else if(sortingByName != 0){
            Collections.sort(this.processList, new Comparator<Process>() {
                @Override
                public int compare(Process process1, Process process2) {
                    if(process1.getName().equals(process2.getName()))
                        return 0;

                    if(sortingByName == 1)
                        return process1.getName().compareTo(process2.getName());
                    else
                        return -1 * process1.getName().compareTo(process2.getName());
                }
            });
        }
    }

    private void filter(){
        if(this.filterBy .equals(""))
            return;

        ArrayList<Process> newList = new ArrayList<Process>();

        for(Process process : this.processList){
            if(process.getName().contains(this.filterBy) ||
                String.valueOf(process.getPid()).contains(this.filterBy))
                newList.add(process);
        }

        this.processList = newList;
    }

    public void setSort(int sortingByName, int sortingByPid){
        this.sortingByName = sortingByName;
        this.sortingByPid = sortingByPid;
    }

    public void setFiler(String filter){
        this.filterBy = filter;
    }

    @NonNull
    @Override
    public ProcessViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.process_list_item, parent, false);

        return new ProcessViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProcessViewHolder holder, int position) {
        holder.bindProcess(this.processList.get(position));
    }

    @Override
    public int getItemCount() {
        return this.processList.size();
    }
}
