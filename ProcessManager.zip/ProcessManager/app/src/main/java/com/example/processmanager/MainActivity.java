package com.example.processmanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.SearchView;
import android.widget.TextView;

import com.example.processmanager.recyclerviewclasses.ProcessListAdaptor;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import com.example.processmanager.ProcessManager.Process;

public class MainActivity extends AppCompatActivity {
    private ProcessListAdaptor adaptor;
    private int sortingByName = 0;
    private int sortingByPid = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // the root check will also ask for permission for root access if a root permission
        // manager is installed on the phone.
        if(!RootUtil.isDeviceRooted()){
            ProcessManager.setWithRoot(false);
            ProcessManager.prepareDummyProcesses();
            showNotRootedDialog();
        }

        RecyclerView processListView = findViewById(R.id.processList);
        adaptor = new ProcessListAdaptor(ProcessManager.getProcesses(), new ProcessListAdaptor.KillCallback() {
            @Override
            public void onKill() {
                MainActivity.this.refreshProcessList();
            }
        });
        processListView.setAdapter(adaptor);
        processListView.setLayoutManager(new LinearLayoutManager(this));

        FloatingActionButton refreshButton = findViewById(R.id.fabRefresh);
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MainActivity.this.refreshProcessList();
            }
        });

        SearchView searchBar = findViewById(R.id.search_bar);
        searchBar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                MainActivity.this.adaptor.setFiler(s);
                MainActivity.this.refreshProcessList();
                return false;
            }
        });

        TextView sortByName = findViewById(R.id.name_text);
        TextView sortByPid = findViewById(R.id.pid_text);

        sortByName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(MainActivity.this.sortingByPid > 0)
                    return;

                MainActivity.this.sortingByName = (MainActivity.this.sortingByName + 1) % 3;

                int color;
                String text;
                if(MainActivity.this.sortingByName == 0){
                    color = getResources().getColor(R.color.teal_200);
                    text = "Name";
                }
                else if(MainActivity.this.sortingByName == 1){
                    color = getResources().getColor(R.color.teal_700);
                    text = "Name Asc";
                }
                else{
                    color = getResources().getColor(R.color.teal_700);
                    text = "Name Desc";
                }

                sortByName.setBackgroundColor(color);
                sortByName.setText(text);
                MainActivity.this.adaptor.setSort(sortingByName, sortingByPid);
                MainActivity.this.refreshProcessList();
            }
        });

        sortByPid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(MainActivity.this.sortingByName > 0)
                    return;

                MainActivity.this.sortingByPid = (MainActivity.this.sortingByPid + 1) % 3;

                int color;
                String text;
                if(MainActivity.this.sortingByPid == 0){
                    color = getResources().getColor(R.color.teal_200);
                    text = "PID";
                }
                else if(MainActivity.this.sortingByPid == 1){
                    color = getResources().getColor(R.color.teal_700);
                    text = "PID Asc";
                }
                else{
                    color = getResources().getColor(R.color.teal_700);
                    text = "PID Desc";
                }

                sortByPid.setBackgroundColor(color);
                sortByPid.setText(text);
                MainActivity.this.adaptor.setSort(sortingByName, sortingByPid);
                MainActivity.this.refreshProcessList();
            }
        });

    }

    private void showNotRootedDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Device is not rooted!! This app can manage only owned processes :(")
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // nothing
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    private void refreshProcessList() {
        ArrayList<Process> processList = ProcessManager.getProcesses();
        System.out.println("PROCESS_PRINT");
        for(Process process : processList){
            System.out.println("Process: " + process.getPid() + " " + process.getName());
        }

        this.adaptor.refreshList(processList);
    }
}