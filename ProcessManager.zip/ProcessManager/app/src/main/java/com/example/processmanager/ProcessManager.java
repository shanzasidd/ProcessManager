package com.example.processmanager;

import android.util.Log;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Comparator;

public class ProcessManager {
    private static final String LOG_TAG = "PROCESS_MANAGER";
    private static boolean withRoot = true;

    public static void setWithRoot(boolean withRoot) {
        ProcessManager.withRoot = withRoot;
    }

    public static boolean isWithRoot() {
        return withRoot;
    }

    public static class Process {
        private final int pid;
        private final String name;

        public Process(int pid, String name){
            this.pid = pid;
            this.name = name;
        }

        public int getPid(){ return this.pid;}
        public String getName() {return this.name;}
    }

    public static ArrayList<Process> getProcesses(){
        return parseProcesses(ps());
    }

    public static void killProcess(Process process){
        if(withRoot){
            try {
                java.lang.Process suProcess = RootUtil.getSuProcess();

                DataOutputStream writeTo = new DataOutputStream(suProcess.getOutputStream());

                writeTo.writeBytes("kill " + process.getPid() + "\n");
                writeTo.flush();

                writeTo.writeBytes("exit\n");
                writeTo.flush();

            } catch (Exception e){
                Log.d(LOG_TAG, "killProcess: failed to kill (no permission?): " + e.getMessage());
            }

        }
        else{
            android.os.Process.killProcess(process.getPid());
        }
    }

    private static ArrayList<Process> parseProcesses(ArrayList<String> string_processes){
        ArrayList<Process> processes = new ArrayList<>();

        for(String string_process : string_processes){
            ArrayList<String> process_elems = split(string_process);
            processes.add(new Process(Integer.parseInt(process_elems.get(1)), process_elems.get(8)));
        }

        return processes;
    }

    private static ArrayList<String> split(String string){
        ArrayList<String> splitRes = new ArrayList<String>();

        if(string == null){
            return splitRes;
        }

        int begin = 0;
        boolean lastSpace = false;

        for(int i = 0; i < string.length(); i++){
            if(string.charAt(i) == ' ' || string.charAt(i) == '\n'){
                if(i > begin && !lastSpace)
                    splitRes.add(string.substring(begin, i));

                lastSpace = true;
            }
            else if(lastSpace){
                begin = i;
                lastSpace = false;
            }
        }

        if(!lastSpace){
            splitRes.add(string.substring(begin, string.length()));
        }

        return splitRes;
    }

    // these methods are called to create dummy processes when the device is not rooted
    // for the sake of displaying the process management capabilities of the app
    public static void prepareDummyProcesses(){
        prepareDummyProcesses(10);
    }

    public static void prepareDummyProcesses(int processNo){
        for(int i = 0; i < processNo; i++){
            try {
                Runtime.getRuntime().exec("sleep 600");
            }
            catch (Exception e){
                // nothing
            }
        }
    }

    private static ArrayList<String> ps(){
        ArrayList<String> out_processes = new ArrayList<>();

        try {
            java.lang.Process process;

            if(withRoot){
                process = RootUtil.getSuProcess();

                DataOutputStream writeTo = new DataOutputStream(process.getOutputStream());
                BufferedReader readFrom = new BufferedReader(new InputStreamReader(process.getInputStream()));

                writeTo.writeBytes("ps -A\n");
                writeTo.flush();

                boolean first = true;
                String line;
                while((line = readFrom.readLine()) != null){
                    if(!first)
                        out_processes.add(line);
                    else
                        first = false;
                }

                writeTo.writeBytes("exit\n");
                writeTo.flush();
            }
            else {
                process = Runtime.getRuntime().exec("ps -A");

                BufferedReader readFrom = new BufferedReader(new InputStreamReader(process.getInputStream()));

                boolean first = true;
                String line;
                while((line = readFrom.readLine()) != null){
                    if(!first)
                        out_processes.add(line);
                    else
                        first = false;
                }
            }

        } catch (Exception e) {
            Log.d(LOG_TAG, "ps: " + e.getMessage());
        }

        return out_processes;
    }

}
